import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { addToWaitlist, getWaitlistCount, getWaitlistByEmail } from "./db";
import { z } from "zod";
import { TRPCError } from "@trpc/server";

export const appRouter = router({
  // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  waitlist: router({
    join: publicProcedure
      .input(
        z.object({
          email: z.string().email(),
          name: z.string().min(1),
          phone: z.string().min(1),
          role: z.string().min(1),
          annualRevenue: z.string().min(1),
          aiUrgency: z.string().min(1),
        })
      )
      .mutation(async ({ input }) => {
        try {
          // Check if email already exists
          const existing = await getWaitlistByEmail(input.email);
          if (existing) {
            return {
              success: false,
              error: "Email already on waitlist",
              position: existing.position,
              name: existing.name,
            };
          }

          const result = await addToWaitlist({
            email: input.email,
            name: input.name,
            phone: input.phone,
            role: input.role,
            annualRevenue: input.annualRevenue,
            aiUrgency: input.aiUrgency,
            position: 0, // Will be set by the database helper
          });

          return {
            success: true,
            position: result.position,
            name: result.name,
          };
        } catch (error) {
          console.error("Waitlist join error:", error);
          return {
            success: false,
            error: error instanceof Error ? error.message : "Failed to join waitlist",
          };
        }
      }),
    count: publicProcedure.query(async () => {
      const count = await getWaitlistCount();
      return { count };
    }),
  }),

  // TODO: add feature routers here, e.g.
  // todo: router({
  //   list: protectedProcedure.query(({ ctx }) =>
  //     db.getUserTodos(ctx.user.id)
  //   ),
  // }),
});

export type AppRouter = typeof appRouter;
