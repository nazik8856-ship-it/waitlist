import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// Mock context for testing
function createMockContext(): TrpcContext {
  return {
    user: null,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };
}

describe("waitlist API", () => {
  it("should join the waitlist with valid data", async () => {
    const ctx = createMockContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.waitlist.join({
      email: "test@example.com",
      name: "Test User",
      phone: "+1234567890",
      role: "Founder/CEO",
      annualRevenue: "$1M - $5M",
      aiUrgency: "High",
    });

    expect(result.success).toBe(true);
    expect(result.position).toBeGreaterThan(0);
    expect(result.name).toBe("Test User");
  });

  it("should prevent duplicate email signups", async () => {
    const ctx = createMockContext();
    const caller = appRouter.createCaller(ctx);

    // First signup
    await caller.waitlist.join({
      email: "duplicate@example.com",
      name: "First User",
      phone: "+1234567890",
      role: "Founder/CEO",
      annualRevenue: "$1M - $5M",
      aiUrgency: "High",
    });

    // Second signup with same email
    const result = await caller.waitlist.join({
      email: "duplicate@example.com",
      name: "Second User",
      phone: "+1234567890",
      role: "COO",
      annualRevenue: "$5M - $10M",
      aiUrgency: "Critical",
    });

    expect(result.success).toBe(false);
    expect(result.error).toContain("already on waitlist");
  });

  it("should get the waitlist count", async () => {
    const ctx = createMockContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.waitlist.count();

    expect(result.count).toBeGreaterThanOrEqual(0);
    expect(typeof result.count).toBe("number");
  });

  it("should assign incrementing positions", async () => {
    const ctx = createMockContext();
    const caller = appRouter.createCaller(ctx);

    const result1 = await caller.waitlist.join({
      email: `test${Date.now()}@example.com`,
      name: "User 1",
      phone: "+1234567890",
      role: "Founder/CEO",
      annualRevenue: "$1M - $5M",
      aiUrgency: "High",
    });

    const result2 = await caller.waitlist.join({
      email: `test${Date.now() + 1}@example.com`,
      name: "User 2",
      phone: "+1234567890",
      role: "COO",
      annualRevenue: "$5M - $10M",
      aiUrgency: "Critical",
    });

    if (result1.success && result2.success) {
      expect(result2.position).toBeGreaterThan(result1.position);
    }
  });
});
