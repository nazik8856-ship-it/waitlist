import React, { useRef, useState } from "react";
import { ManusDialog } from "@/components/ManusDialog";
import { motion, useInView, AnimatePresence } from "motion/react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import {
  Zap,
  BarChart3,
  MessageSquare,
  Rocket,
  ArrowRight,
  CheckCircle2,
  Mail,
  Star,
  ChevronRight,
  Globe,
  Users,
  X,
  Check,
  ChevronLeft,
} from "lucide-react";

// ─────────────────────────────────────────────────────────────
// CONSTANTS
// ─────────────────────────────────────────────────────────────

const LASER_PURPLE = "#d946ef";
const LASER_PURPLE_DIM = "#a21caf";
const CYAN = "#06b6d4";

const DEMO_STEPS = [
  {
    icon: Zap,
    title: "Live AI Generation",
    desc: "Watch NazAI build a complete business strategy, website, and brand assets in real time — for your specific company.",
    color: CYAN,
    step: "01",
  },
  {
    icon: BarChart3,
    title: "Business Intelligence",
    desc: "Deep-dive into Logic Gate's reasoning. See how NazAI maps your market, competitors, and 5-year growth trajectory.",
    color: LASER_PURPLE,
    step: "02",
  },
  {
    icon: MessageSquare,
    title: "Live Q&A Session",
    desc: "Ask anything. Our founders walk you through every feature, answer edge cases, and tailor the demo to your use case.",
    color: CYAN,
    step: "03",
  },
  {
    icon: Rocket,
    title: "Your Launch Plan",
    desc: "Leave with a custom onboarding roadmap. Know exactly how NazAI integrates into your workflow from day one.",
    color: LASER_PURPLE,
    step: "04",
  },
];

const STATS = [
  { value: "2,400+", label: "Early Members", color: CYAN },
  { value: "94%", label: "Would Recommend", color: LASER_PURPLE },
  { value: "48 hrs", label: "Avg. Onboarding", color: CYAN },
  { value: "#1", label: "AI Business OS", color: LASER_PURPLE },
];

const TESTIMONIALS = [
  {
    name: "Priya Sharma",
    role: "Ops Lead",
    company: "NorthBeam",
    text: '"Our 12-month cash-flow model and hiring plan landed in the Vault before our standup ended."',
    match: "90.1% Match",
    metric: "Cut planning time 87%",
    initials: "PS",
    color: "#f59e0b",
  },
  {
    name: "Alex Nguyen",
    role: "Indie Developer",
    company: "Pixelmint",
    text: '"Asset Synthesis nailed our palette on the first pass. Every iteration archived to the Vault — replayable any time."',
    match: "91.0% Match",
    metric: "Saved 18 hrs/week",
    initials: "AN",
    color: LASER_PURPLE,
  },
  {
    name: "Jordan Tate",
    role: "Head of Growth",
    company: "Helo Studio",
    text: '"Mission Briefs are a cheat code. Successful generation with every prompt — no wasted credits."',
    match: "96.8% Match",
    metric: "200 SEO pages in one afternoon",
    initials: "JT",
    color: CYAN,
  },
  {
    name: "Sasha Keller",
    role: "Founder",
    company: "Keller Studio",
    text: '"NazAI auto-corrected three briefs I\'ve shipped. Felt like a senior strategist was right beside me."',
    match: "94.2% Match",
    metric: "3x output velocity",
    initials: "SK",
    color: "#10b981",
  },
];

// ─────────────────────────────────────────────────────────────
// SHARED COMPONENTS
// ─────────────────────────────────────────────────────────────

function Orbs() {
  return (
    <div className="pointer-events-none fixed inset-0 overflow-hidden">
      <div
        className="absolute rounded-full blur-[130px] opacity-[0.18]"
        style={{
          width: 650,
          height: 650,
          top: "-12%",
          left: "-8%",
          background: `radial-gradient(circle, ${CYAN} 0%, transparent 70%)`,
        }}
      />
      <div
        className="absolute rounded-full blur-[170px] opacity-[0.16]"
        style={{
          width: 750,
          height: 750,
          top: "25%",
          right: "-18%",
          background: `radial-gradient(circle, ${LASER_PURPLE} 0%, transparent 70%)`,
        }}
      />
      <div
        className="absolute rounded-full blur-[100px] opacity-[0.10]"
        style={{
          width: 420,
          height: 420,
          bottom: "8%",
          left: "28%",
          background: `radial-gradient(circle, ${CYAN} 0%, transparent 70%)`,
        }}
      />
      <div
        className="absolute inset-0 opacity-[0.025]"
        style={{
          backgroundImage: `linear-gradient(${CYAN}88 1px, transparent 1px), linear-gradient(90deg, ${CYAN}88 1px, transparent 1px)`,
          backgroundSize: "60px 60px",
        }}
      />
    </div>
  );
}

function Reveal({
  children,
  delay = 0,
  className = "",
}: {
  children: React.ReactNode;
  delay?: number;
  className?: string;
}) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-60px" });
  return (
    <motion.div
      ref={ref}
      className={className}
      initial={{ opacity: 0, y: 32 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.65, delay, ease: [0.25, 0.1, 0.25, 1] as const }}
    >
      {children}
    </motion.div>
  );
}

function CyanBadge({ text }: { text: string }) {
  return (
    <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-cyan-500/30 bg-cyan-500/5 text-cyan-400 text-xs font-semibold tracking-[0.2em] uppercase mb-6">
      <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
      {text}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// WAITLIST MODAL
// ─────────────────────────────────────────────────────────────

type WaitlistStep = 1 | 2 | 3 | 4;
type FormData = {
  role: string;
  annualRevenue: string;
  aiUrgency: string;
  email: string;
  name: string;
  phone: string;
};

const ROLES = ["Founder/CEO", "COO", "CTO", "CMO", "Other"];
const REVENUES = ["<$100K", "$100K - $1M", "$1M - $5M", "$5M - $10M", "$10M+"];
const URGENCIES = ["Critical", "High", "Medium", "Low"];

function OptionButton({
  label,
  selected,
  onClick,
}: {
  label: string;
  selected: boolean;
  onClick: () => void;
}) {
  return (
    <motion.button
      type="button"
      onClick={onClick}
      className="w-full text-left px-4 py-3 rounded-xl border text-sm font-medium transition-all duration-200 cursor-pointer"
      style={
        selected
          ? {
              borderColor: `${LASER_PURPLE}80`,
              background: `${LASER_PURPLE}18`,
              color: "#fff",
              boxShadow: `0 0 18px ${LASER_PURPLE}28`,
            }
          : {
              borderColor: "rgba(255,255,255,0.08)",
              background: "rgba(255,255,255,0.03)",
              color: "rgba(255,255,255,0.55)",
            }
      }
      whileHover={{ scale: 1.01 }}
      whileTap={{ scale: 0.98 }}
    >
      <div className="flex items-center justify-between">
        <span>{label}</span>
        {selected && <Check className="w-4 h-4 flex-shrink-0" style={{ color: LASER_PURPLE }} />}
      </div>
    </motion.button>
  );
}

function ProgressDots({ step }: { step: WaitlistStep }) {
  return (
    <div className="flex items-center gap-2 justify-center mb-5">
      {([1, 2, 3, 4] as WaitlistStep[]).map((s) => (
        <div
          key={s}
          className="rounded-full transition-all duration-400"
          style={{
            width: s === step ? 24 : 8,
            height: 8,
            background:
              s < step
                ? CYAN
                : s === step
                  ? LASER_PURPLE
                  : "rgba(255,255,255,0.12)",
            boxShadow: s === step ? `0 0 12px ${LASER_PURPLE}80` : undefined,
          }}
        />
      ))}
    </div>
  );
}

function WaitlistModal({
  onClose,
  onSuccess,
}: {
  onClose: () => void;
  onSuccess: (position: number, name: string | undefined) => void;
}) {
  const [step, setStep] = useState<WaitlistStep>(1);
  const [form, setForm] = useState<FormData>({
    role: "",
    annualRevenue: "",
    aiUrgency: "",
    email: "",
    name: "",
    phone: "",
  });
  const [loading, setLoading] = useState(false);

  const goNext = () => setStep((s) => (s + 1) as WaitlistStep);

  const joinMutation = trpc.waitlist.join.useMutation();

  const handleSubmit = async () => {
    if (!form.email || !form.name || !form.phone) {
      toast.error("Please fill in all fields.");
      return;
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(form.email)) {
      toast.error("Please enter a valid email address.");
      return;
    }
    setLoading(true);
    try {
      const result = await joinMutation.mutateAsync({
        email: form.email,
        name: form.name,
        phone: form.phone,
        role: form.role,
        annualRevenue: form.annualRevenue,
        aiUrgency: form.aiUrgency,
      });

      if (!result.success) {
        throw new Error(result.error || 'Failed to join waitlist');
      }

      onSuccess(result.position ?? 0, result.name ?? 'User');
      toast.success("Successfully joined the waitlist!");
    } catch (err) {
      const message = err instanceof Error ? err.message : "Something went wrong. Please try again.";
      toast.error(message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-start md:items-center justify-center p-4 pt-8 md:pt-4"
      style={{ background: "rgba(2,6,23,0.85)", backdropFilter: "blur(12px)" }}
    >
      <motion.div
        className="relative w-full max-w-lg rounded-3xl border overflow-y-auto max-h-[92vh]"
        style={{
          background: "linear-gradient(160deg, rgba(15,15,35,0.98) 0%, rgba(2,6,23,0.99) 100%)",
          borderColor: `${LASER_PURPLE}35`,
          boxShadow: `0 0 80px ${LASER_PURPLE}20, 0 0 120px ${CYAN}10`,
        }}
        initial={{ opacity: 0, scale: 0.93, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.93, y: 20 }}
        transition={{ duration: 0.35, ease: [0.25, 0.1, 0.25, 1] as const }}
      >
        {/* top accent */}
        <div
          className="sticky top-0 h-px w-full z-10"
          style={{ background: `linear-gradient(90deg, transparent, ${LASER_PURPLE}, ${CYAN}, transparent)` }}
        />

        <div className="p-6 md:p-8">
          {/* header row */}
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
            <div
              className="w-8 h-8 rounded-lg overflow-hidden flex items-center justify-center font-black text-sm text-white"
              style={{ background: `linear-gradient(135deg, ${CYAN}, ${LASER_PURPLE})`, boxShadow: `0 0 14px ${CYAN}50` }}
            >
            <img
              src="https://d2xsxph8kpxj0f.cloudfront.net/310519663631894654/ShQiNtFkjnG8UahdvqCfHj/nazai-logo-RvG5ZxH2jPTALAVqRY6vpb.webp"
              alt="NazAI"
              className="w-full h-full object-cover"
              onError={(e) => { (e.currentTarget as HTMLImageElement).style.display = "none"; }}
            />
            </div>
              <span className="font-bold text-white">NazAI</span>
            </div>
            <button
              onClick={onClose}
              className="text-white/35 hover:text-white/60 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <ProgressDots step={step} />

          {/* content */}
          <AnimatePresence mode="wait">
            {step === 1 && (
              <motion.div
                key="step1"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.25 }}
              >
                <h2 className="text-lg font-black text-white mb-1">What's your role?</h2>
                <p className="text-xs text-white/35 mb-4">Help us tailor NazAI to your needs.</p>
                <div className="space-y-2">
                  {ROLES.map((r) => (
                    <OptionButton
                      key={r}
                      label={r}
                      selected={form.role === r}
                      onClick={() => {
                        setForm((f) => ({ ...f, role: r }));
                        setTimeout(goNext, 180);
                      }}
                    />
                  ))}
                </div>
              </motion.div>
            )}

            {step === 2 && (
              <motion.div
                key="step2"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.25 }}
              >
                <h2 className="text-lg font-black text-white mb-1">What's your annual revenue?</h2>
                <p className="text-xs text-white/35 mb-4">We'll match you to the right NazAI tier.</p>
                <div className="space-y-2">
                  {REVENUES.map((r) => (
                    <OptionButton
                      key={r}
                      label={r}
                      selected={form.annualRevenue === r}
                      onClick={() => {
                        setForm((f) => ({ ...f, annualRevenue: r }));
                        setTimeout(goNext, 180);
                      }}
                    />
                  ))}
                </div>
              </motion.div>
            )}

            {step === 3 && (
              <motion.div
                key="step3"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.25 }}
              >
                <h2 className="text-lg font-black text-white mb-1">How urgent is AI automation?</h2>
                <p className="text-xs text-white/35 mb-4">Based on your current operations.</p>
                <div className="space-y-2">
                  {URGENCIES.map((u) => (
                    <OptionButton
                      key={u}
                      label={u}
                      selected={form.aiUrgency === u}
                      onClick={() => {
                        setForm((f) => ({ ...f, aiUrgency: u }));
                        setTimeout(goNext, 180);
                      }}
                    />
                  ))}
                </div>
              </motion.div>
            )}

            {step === 4 && (
              <motion.div
                key="step4"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.25 }}
              >
                <h2 className="text-lg font-black text-white mb-1">Almost Done!</h2>
                <p className="text-xs text-white/35 mb-4">We'll send your access confirmation here.</p>
                <div className="space-y-3">
                  {(
                    [
                      { field: "name" as const, label: "Full Name", placeholder: "John Smith", type: "text" },
                      { field: "email" as const, label: "Email Address", placeholder: "john@company.com", type: "email" },
                      { field: "phone" as const, label: "Phone Number", placeholder: "+1 (555) 000-0000", type: "tel" },
                    ]
                  ).map(({ field, label, placeholder, type }) => (
                    <div key={field}>
                      <label className="block text-xs font-semibold text-white/40 tracking-widest uppercase mb-1.5">
                        {label}
                      </label>
                      <input
                        type={type}
                        value={form[field]}
                        onChange={(e) => setForm((f) => ({ ...f, [field]: e.target.value }))}
                        placeholder={placeholder}
                        className="w-full px-4 py-3 rounded-xl text-sm text-white placeholder-white/20 outline-none transition-all duration-200"
                        style={{
                          background: "rgba(255,255,255,0.04)",
                          border: `1px solid rgba(255,255,255,0.10)`,
                        }}
                        onFocus={(e) => {
                          e.currentTarget.style.borderColor = `${LASER_PURPLE}60`;
                          e.currentTarget.style.boxShadow = `0 0 20px ${LASER_PURPLE}18`;
                        }}
                        onBlur={(e) => {
                          e.currentTarget.style.borderColor = "rgba(255,255,255,0.10)";
                          e.currentTarget.style.boxShadow = "none";
                        }}
                      />
                    </div>
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* nav buttons */}
          <div className="flex items-center justify-between mt-4 pb-2 gap-3">
            {step > 1 ? (
              <button
                type="button"
                onClick={() => setStep((s) => (s - 1) as WaitlistStep)}
                className="flex items-center gap-1.5 text-sm text-white/35 hover:text-white/60 cursor-pointer transition-colors"
              >
                <ChevronLeft className="w-4 h-4" /> Back
              </button>
            ) : (
              <div />
            )}

            {step === 4 && (
              <motion.button
                type="button"
                onClick={handleSubmit}
                disabled={loading}
                className="flex items-center gap-2 px-7 py-3 rounded-xl text-sm font-bold cursor-pointer"
                style={{
                  background: `linear-gradient(135deg, ${LASER_PURPLE}, ${LASER_PURPLE_DIM})`,
                  color: "#fff",
                  boxShadow: `0 0 30px ${LASER_PURPLE}45`,
                  opacity: loading ? 0.7 : 1,
                }}
                whileHover={!loading ? { scale: 1.03 } : {}}
                whileTap={!loading ? { scale: 0.97 } : {}}
              >
                {loading ? (
                  <>
                    <div className="w-4 h-4 rounded-full border-2 border-white/30 border-t-white animate-spin" />
                    Securing spot...
                  </>
                ) : (
                  <>
                    Claim My Spot <Check className="w-4 h-4" />
                  </>
                )}
              </motion.button>
            )}
          </div>
        </div>
      </motion.div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// CONFIRMATION VIEW
// ─────────────────────────────────────────────────────────────

function ConfirmationView({ position, name, onClose }: { position: number; name: string | undefined; onClose: () => void }) {
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: "rgba(2,6,23,0.88)", backdropFilter: "blur(14px)" }}
    >
      <motion.div
        className="relative w-full max-w-lg rounded-3xl border overflow-y-auto max-h-[92vh] text-center"
        style={{
          background: "linear-gradient(160deg, rgba(15,15,35,0.98) 0%, rgba(2,6,23,0.99) 100%)",
          borderColor: `${LASER_PURPLE}40`,
          boxShadow: `0 0 100px ${LASER_PURPLE}25, 0 0 60px ${CYAN}10`,
        }}
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.45, ease: [0.25, 0.1, 0.25, 1] as const }}
      >
        <div
          className="h-px w-full"
          style={{ background: `linear-gradient(90deg, transparent, ${LASER_PURPLE}, ${CYAN}, transparent)` }}
        />
        <div className="p-7 md:p-10">
          {/* animated check */}
          <motion.div
            className="w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-7"
            style={{
              background: `linear-gradient(135deg, ${LASER_PURPLE}30, ${CYAN}20)`,
              border: `1px solid ${LASER_PURPLE}40`,
              boxShadow: `0 0 50px ${LASER_PURPLE}30`,
            }}
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
          >
            <Check className="w-9 h-9 text-white" />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.35 }}
          >
            <div
              className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-bold tracking-[0.2em] uppercase mb-5 border"
              style={{ color: LASER_PURPLE, borderColor: `${LASER_PURPLE}35`, background: `${LASER_PURPLE}10` }}
            >
              <span className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ background: LASER_PURPLE }} />
              Position #{position} Secured
            </div>

            <h2 className="text-2xl md:text-3xl font-black text-white mb-4 leading-tight">
              Welcome to the list,{" "}
              <span style={{ color: LASER_PURPLE }}>{(name ?? 'User').split(" ")[0]}.</span>
              <br />
              We're glad you're here.
            </h2>

            <p className="text-sm text-white/45 leading-relaxed mb-6 max-w-sm mx-auto">
              You've officially joined the NazAI waitlist — and that means a lot to us. We're
              building something we believe in, and knowing you're waiting makes it even more worth
              building. We'll be in touch soon.
            </p>

            <div
              className="rounded-2xl p-5 mb-2 border text-left"
              style={{ background: "rgba(255,255,255,0.03)", borderColor: "rgba(255,255,255,0.07)" }}
            >
              <div className="text-xs font-bold tracking-widest text-white/25 uppercase mb-3">
                Your Waitlist Position
              </div>
              <div className="flex items-center gap-4">
                <div
                  className="text-5xl font-black"
                  style={{
                    background: `linear-gradient(135deg, ${LASER_PURPLE}, ${CYAN})`,
                    WebkitBackgroundClip: "text",
                    WebkitTextFillColor: "transparent",
                  }}
                >
                  #{position}
                </div>
                <div>
                  <div className="text-white font-semibold text-sm">{name}</div>
                  <div className="text-white/35 text-xs mt-0.5">
                    Access confirmation will be sent by email when we launch.
                  </div>
                </div>
              </div>
            </div>

            <motion.button
              onClick={onClose}
              className="mt-6 px-8 py-3 rounded-xl text-sm font-bold cursor-pointer"
              style={{
                background: `linear-gradient(135deg, ${LASER_PURPLE}20, ${CYAN}20)`,
                color: "#fff",
                border: `1px solid ${LASER_PURPLE}30`,
              }}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              Close
            </motion.button>
          </motion.div>
        </div>
      </motion.div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// TESTIMONIALS MARQUEE
// ─────────────────────────────────────────────────────────────

function TestimonialCard({ t }: { t: (typeof TESTIMONIALS)[0] }) {
  return (
    <div
      className="flex-shrink-0 w-80 md:w-96 rounded-2xl border p-6 mx-3 cursor-default"
      style={{
        background: "linear-gradient(135deg, rgba(255,255,255,0.04) 0%, rgba(255,255,255,0.02) 100%)",
        backdropFilter: "blur(12px)",
        borderColor: "rgba(255,255,255,0.07)",
      }}
    >
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-1.5 text-[10px] font-bold tracking-[0.15em] uppercase border rounded-full px-2.5 py-1"
          style={{ color: `${CYAN}cc`, borderColor: `${CYAN}25` }}>
          <CheckCircle2 className="w-3 h-3" /> VERIFIED MISSION
        </div>
        <span className="text-xs font-bold" style={{ color: CYAN }}>{t.match}</span>
      </div>
      <p className="text-sm text-white/75 leading-relaxed mb-5 italic">{t.text}</p>
      <div className="flex items-center gap-1.5 text-[11px] font-semibold text-emerald-400 mb-5">
        <ArrowRight className="w-3 h-3" /> {t.metric}
      </div>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold text-white"
            style={{ background: t.color }}>
            {t.initials}
          </div>
          <div>
            <div className="text-sm font-semibold text-white">{t.name}</div>
            <div className="text-xs text-white/35">{t.role} · {t.company}</div>
          </div>
        </div>
        <div className="flex items-center gap-0.5">
          {Array.from({ length: 5 }).map((_, i) => (
            <Star key={i} className="w-3 h-3 fill-amber-400 text-amber-400" />
          ))}
        </div>
      </div>
    </div>
  );
}

function TestimonialsMarquee() {
  const doubled = [...TESTIMONIALS, ...TESTIMONIALS];
  return (
    <div className="relative overflow-hidden">
      <div className="absolute left-0 top-0 bottom-0 w-24 z-10 pointer-events-none bg-gradient-to-r from-[#020617] to-transparent" />
      <div className="absolute right-0 top-0 bottom-0 w-24 z-10 pointer-events-none bg-gradient-to-l from-[#020617] to-transparent" />
      <motion.div
        className="flex py-4"
        animate={{ x: ["0%", "-50%"] }}
        transition={{ duration: 45, ease: "linear", repeat: Infinity }}
      >
        {doubled.map((t, i) => <TestimonialCard key={i} t={t} />)}
      </motion.div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// FOOTER
// ─────────────────────────────────────────────────────────────

function TikTokIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor">
      <path d="M19.59 6.69a4.83 4.83 0 01-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 01-2.88 2.5 2.89 2.89 0 01-2.89-2.89 2.89 2.89 0 012.89-2.89c.28 0 .54.04.79.1V9.01a6.33 6.33 0 00-.79-.05 6.34 6.34 0 00-6.34 6.34 6.34 6.34 0 006.34 6.34 6.34 6.34 0 006.33-6.34V8.79a8.18 8.18 0 004.79 1.54V6.89a4.85 4.85 0 01-1.02-.2z" />
    </svg>
  );
}

function Footer() {
  return (
    <footer className="border-t mt-24" style={{ background: "rgba(2,6,23,0.97)", borderColor: "rgba(255,255,255,0.05)" }}>
      <div className="max-w-6xl mx-auto px-6 py-14">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10">
          <div className="md:col-span-1">
            <div className="flex items-center gap-2.5 mb-4">
            <div className="w-9 h-9 rounded-xl overflow-hidden flex items-center justify-center font-black text-sm text-white"
              style={{ background: `linear-gradient(135deg, ${CYAN}, ${LASER_PURPLE})`, boxShadow: `0 0 20px ${CYAN}40` }}>
              <img
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663631894654/ShQiNtFkjnG8UahdvqCfHj/nazai-logo-RvG5ZxH2jPTALAVqRY6vpb.webp"
                alt="NazAI"
                className="w-full h-full object-cover"
                onError={(e) => { (e.currentTarget as HTMLImageElement).style.display = "none"; }}
              />
            </div>
              <span className="font-bold text-lg text-white tracking-tight">NazAI</span>
            </div>
            <p className="text-xs text-white/30 leading-relaxed mb-4">Built for the Future.</p>
            <div className="text-[10px] font-bold tracking-[0.25em] uppercase" style={{ color: `${CYAN}99` }}>
              AI Business OS
            </div>
          </div>
          <div>
            <div className="text-[10px] font-bold tracking-[0.2em] text-white/25 uppercase mb-4">Product</div>
            {["Domain Master", "Brand-Snap Canvas", "Operations"].map((item) => (
              <div key={item} className="text-sm text-white/45 hover:text-white/80 cursor-pointer transition-colors py-1.5">{item}</div>
            ))}
          </div>
          <div>
            <div className="text-[10px] font-bold tracking-[0.2em] text-white/25 uppercase mb-4">Company</div>
            <a href="https://www.youtube.com/@NazAI-n8b" target="_blank" rel="noopener noreferrer"
              className="flex items-center gap-2 text-sm text-white/45 hover:text-red-400 transition-colors py-1.5">
              <svg className="w-3.5 h-3.5" viewBox="0 0 24 24" fill="currentColor">
                <path d="M23.498 6.186a3.016 3.016 0 00-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 00.502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 002.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 002.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" />
              </svg>
              YouTube
            </a>
            <a href="https://www.tiktok.com/@nazai.ai.business" target="_blank" rel="noopener noreferrer"
              className="flex items-center gap-2 text-sm text-white/45 hover:text-white transition-colors py-1.5">
              <TikTokIcon className="w-3.5 h-3.5" />
              TikTok
            </a>
            <a href="mailto:nazai8832@gmail.com"
              className="flex items-center gap-2 text-sm text-white/45 transition-colors py-1.5"
              style={{ color: "rgba(255,255,255,0.45)" }}
              onMouseEnter={e => { (e.currentTarget as HTMLAnchorElement).style.color = CYAN; }}
              onMouseLeave={e => { (e.currentTarget as HTMLAnchorElement).style.color = "rgba(255,255,255,0.45)"; }}
            >
              <Mail className="w-3.5 h-3.5" /> Contact
            </a>
          </div>
          <div>
            <div className="text-[10px] font-bold tracking-[0.2em] text-white/25 uppercase mb-4">Legal</div>
            {["Terms", "Privacy Policy"].map((item) => (
              <div key={item} className="text-sm text-white/45 hover:text-white/80 cursor-pointer transition-colors py-1.5">{item}</div>
            ))}
          </div>
        </div>
        <div className="flex flex-col md:flex-row items-center justify-between mt-12 pt-8 border-t" style={{ borderColor: "rgba(255,255,255,0.05)" }}>
          <div className="text-[11px] tracking-[0.15em] text-white/18 uppercase">
            © {new Date().getFullYear()} NazAI Systems
          </div>
          <div className="flex items-center gap-2 text-[11px] tracking-[0.15em] text-white/22 uppercase mt-4 md:mt-0">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            System Operational
          </div>
        </div>
      </div>
    </footer>
  );
}

// ─────────────────────────────────────────────────────────────
// MAIN PAGE
// ─────────────────────────────────────────────────────────────

export default function Landing() {
  const [modalOpen, setModalOpen] = useState(false);
  const [confirmation, setConfirmation] = useState<{ position: number; name: string | undefined } | null>(null);
  const [totalCount, setTotalCount] = useState(0);
  const [showManusDialog, setShowManusDialog] = useState(true);

  const handleSuccess = (position: number, name: string | undefined) => {
    setModalOpen(false);
    setConfirmation({ position, name: name ?? 'User' });
    setTotalCount(prev => prev + 1);
    // Refetch updated count from server
    countQuery.refetch();
  };

  const countQuery = trpc.waitlist.count.useQuery();

  const fetchWaitlistCount = async () => {
    try {
      const data = await countQuery.refetch();
      if (data.data?.count) {
        setTotalCount(data.data.count);
      }
    } catch (error) {
      console.error('Failed to fetch waitlist count:', error);
    }
  };

  // Fetch waitlist count on mount and update when count query changes
  React.useEffect(() => {
    if (countQuery.data?.count) {
      setTotalCount(countQuery.data.count);
    }
  }, [countQuery.data?.count]);

  return (
    <div
      className="min-h-screen text-white overflow-x-hidden"
      style={{ background: "#020617", fontFamily: "'Space Grotesk', 'Inter', sans-serif" }}
    >
      <Orbs />

      {/* ── Navbar ── */}
      <motion.nav
        className="fixed top-0 left-0 right-0 z-40 flex items-center justify-between px-6 md:px-10 py-4"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        style={{ background: "rgba(2,6,23,0.88)", backdropFilter: "blur(20px)", borderBottom: "1px solid rgba(255,255,255,0.05)" }}
      >
        <div className="flex items-center gap-2.5">
          <div
            className="w-8 h-8 rounded-lg overflow-hidden flex items-center justify-center font-black text-sm text-white"
            style={{ background: `linear-gradient(135deg, ${CYAN}, ${LASER_PURPLE})`, boxShadow: `0 0 16px ${CYAN}50` }}
          >
            <img
              src="https://d2xsxph8kpxj0f.cloudfront.net/310519663631894654/ShQiNtFkjnG8UahdvqCfHj/nazai-logo-RvG5ZxH2jPTALAVqRY6vpb.webp"
              alt="NazAI"
              className="w-full h-full object-cover"
              onError={(e) => { (e.currentTarget as HTMLImageElement).style.display = "none"; }}
            />
          </div>
          <span className="font-bold text-base text-white tracking-tight">NazAI</span>
        </div>
        <div className="hidden md:flex items-center gap-8 text-sm text-white/45">
          {["Product", "Use Cases", "Pricing"].map((item) => (
            <span key={item} className="hover:text-white/80 cursor-pointer transition-colors">{item}</span>
          ))}
        </div>
        <motion.button
          onClick={() => setModalOpen(true)}
          className="flex items-center gap-2 text-sm font-bold px-5 py-2 rounded-xl cursor-pointer"
          style={{ background: `linear-gradient(135deg, ${LASER_PURPLE}, ${LASER_PURPLE_DIM})`, color: "#fff", boxShadow: `0 0 22px ${LASER_PURPLE}40` }}
          whileHover={{ scale: 1.04, boxShadow: `0 0 35px ${LASER_PURPLE}60` }}
          whileTap={{ scale: 0.97 }}
        >
          Join Waitlist <ChevronRight className="w-3.5 h-3.5" />
        </motion.button>
      </motion.nav>

      {/* ── Hero ── */}
      <section className="relative flex flex-col items-center justify-center min-h-screen text-center px-6 pt-24 pb-16">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.85, ease: [0.25, 0.1, 0.25, 1] as const }}
        >
          <CyanBadge text="Early Access · Limited Spots" />

          <h1
            className="text-5xl md:text-7xl lg:text-8xl font-black tracking-tight text-balance leading-[1.05] mb-6"
            style={{
              background: "linear-gradient(135deg, #ffffff 0%, rgba(255,255,255,0.72) 100%)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
            }}
          >
            NazAI Orchestrates
            <br />
            <span style={{ background: `linear-gradient(135deg, ${CYAN} 0%, ${LASER_PURPLE} 100%)`, WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
              Any Business Function.
            </span>
          </h1>

          <p className="text-lg md:text-xl text-white/40 max-w-2xl mx-auto leading-relaxed mb-10">
            Unlike simple website builders, NazAI uses its{" "}
            <span style={{ color: CYAN }} className="font-medium">Logic Gate</span> and{" "}
            <span style={{ color: LASER_PURPLE }} className="font-medium">Auto Engine</span>{" "}
            for deep reasoning across all business domains.
          </p>

          <div className="flex flex-col sm:flex-row items-center gap-4 justify-center">
            <motion.button
              onClick={() => setModalOpen(true)}
              className="flex items-center gap-2.5 text-base font-bold px-8 py-4 rounded-xl cursor-pointer"
              style={{
                background: `linear-gradient(135deg, ${LASER_PURPLE}, ${LASER_PURPLE_DIM})`,
                color: "#fff",
                boxShadow: `0 0 50px ${LASER_PURPLE}45`,
              }}
              whileHover={{ scale: 1.04, boxShadow: `0 0 70px ${LASER_PURPLE}65` }}
              whileTap={{ scale: 0.97 }}
            >
              Join Waitlist
              <ArrowRight className="w-4 h-4" />
            </motion.button>

            {totalCount > 0 && (
              <motion.div
                className="flex items-center gap-2 text-sm"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.5 }}
              >
                <div className="flex -space-x-1.5">
                  {["#f59e0b", LASER_PURPLE, CYAN].map((c, i) => (
                    <div key={i} className="w-6 h-6 rounded-full border-2 border-[#020617]" style={{ background: c }} />
                  ))}
                </div>
                <span className="text-white/35">
                  <span className="text-white/60 font-semibold">{totalCount.toLocaleString()}</span> already on the list
                </span>
              </motion.div>
            )}
          </div>
        </motion.div>

        {/* floating particles */}
        {Array.from({ length: 7 }).map((_, i) => (
          <motion.div
            key={i}
            className="absolute rounded-full pointer-events-none"
            style={{
              width: 4 + i * 2,
              height: 4 + i * 2,
              background: i % 2 === 0 ? CYAN : LASER_PURPLE,
              left: `${8 + i * 13}%`,
              top: `${18 + (i % 3) * 24}%`,
              opacity: 0.45,
              filter: "blur(1px)",
            }}
            animate={{ y: [-12, 12, -12], opacity: [0.3, 0.6, 0.3] }}
            transition={{ duration: 3 + i * 0.6, repeat: Infinity, ease: "easeInOut", delay: i * 0.35 }}
          />
        ))}
      </section>

      {/* ── Stats ── */}
      <Reveal>
        <section className="max-w-5xl mx-auto px-6 mb-24">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-px rounded-2xl overflow-hidden border" style={{ background: "rgba(255,255,255,0.04)", borderColor: "rgba(255,255,255,0.07)" }}>
            {STATS.map((s, i) => (
              <div key={i} className="flex flex-col items-center justify-center p-6 md:p-8" style={{ background: "rgba(2,6,23,0.85)" }}>
                <div
                  className="text-3xl md:text-4xl font-black mb-1"
                  style={{ background: `linear-gradient(135deg, ${s.color}, ${s.color}99)`, WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}
                >
                  {s.value}
                </div>
                <div className="text-xs text-white/30 font-medium tracking-wide">{s.label}</div>
              </div>
            ))}
          </div>
        </section>
      </Reveal>

      {/* ── Business Function Cards ── */}
      <section className="max-w-6xl mx-auto px-6 mb-28">
        <Reveal className="text-center mb-14">
          <CyanBadge text="What NazAI Handles" />
          <h2 className="text-3xl md:text-5xl font-black tracking-tight text-white text-balance">
            Every domain.
            <br />
            <span style={{ color: LASER_PURPLE }}>One intelligence.</span>
          </h2>
        </Reveal>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {[
            { icon: "◎", title: "Strategy", desc: "Market research, SWOT, 5-year forecasting.", color: LASER_PURPLE },
            { icon: "⇌", title: "Operations", desc: "Workflow automation, CRM, HR processes.", color: CYAN },
            { icon: "▣", title: "Finance", desc: "Cash flow modeling, tax optimization, contracts.", color: LASER_PURPLE },
            { icon: "◂", title: "Marketing", desc: "Lead gen agents, email sequences, SEO.", color: CYAN },
            { icon: "</>", title: "Tech", desc: "SaaS building, app deployment, API orchestration.", color: LASER_PURPLE },
            { icon: "↗", title: "Scaling", desc: "Hiring plans, international expansion, org design.", color: CYAN },
          ].map((card, i) => (
            <Reveal key={i} delay={i * 0.07}>
              <motion.div
                className="relative group rounded-2xl p-7 border cursor-default overflow-hidden"
                style={{
                  background: "linear-gradient(135deg, rgba(255,255,255,0.04) 0%, rgba(255,255,255,0.02) 100%)",
                  backdropFilter: "blur(12px)",
                  borderColor: "rgba(255,255,255,0.07)",
                }}
                whileHover={{ y: -5, borderColor: `${card.color}45`, boxShadow: `0 20px 60px ${card.color}18` }}
                transition={{ duration: 0.28 }}
              >
                <div className="flex items-start justify-between mb-6">
                  <div
                    className="w-11 h-11 rounded-lg flex items-center justify-center text-lg font-bold"
                    style={{ background: `${card.color}15`, border: `1px solid ${card.color}30`, color: card.color, boxShadow: `0 0 18px ${card.color}20` }}
                  >
                    {card.icon}
                  </div>
                  <ChevronRight className="w-4 h-4 text-white/15 group-hover:text-white/30 transition-colors" />
                </div>
                <h3 className="font-black text-base text-white mb-2 tracking-wide uppercase">{card.title}</h3>
                <p className="text-sm text-white/40 leading-relaxed">{card.desc}</p>
                <div className="absolute bottom-0 left-0 right-0 h-px opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                  style={{ background: `linear-gradient(90deg, transparent, ${card.color}, transparent)` }} />
              </motion.div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* ── Waitlist CTA ── */}
      <section id="waitlist" className="max-w-4xl mx-auto px-6 mb-28 scroll-mt-24">
        <Reveal>
          <div
            className="relative rounded-3xl overflow-hidden border text-center py-16 px-8"
            style={{
              background: `linear-gradient(135deg, ${LASER_PURPLE}10 0%, ${CYAN}08 100%)`,
              backdropFilter: "blur(20px)",
              borderColor: `${LASER_PURPLE}35`,
              boxShadow: `0 0 100px ${LASER_PURPLE}15, 0 0 60px ${CYAN}08`,
            }}
          >
            <div className="h-px w-full absolute top-0 left-0 right-0"
              style={{ background: `linear-gradient(90deg, transparent, ${LASER_PURPLE}, ${CYAN}, transparent)` }} />

            <div className="flex items-center justify-center gap-2 mb-6">
              <Users className="w-4 h-4" style={{ color: LASER_PURPLE }} />
              <span className="text-xs font-bold tracking-[0.2em] uppercase" style={{ color: LASER_PURPLE }}>
                Waitlist Open
              </span>
            </div>

            <h2 className="text-3xl md:text-5xl font-black tracking-tight text-white mb-4 text-balance">
              Secure your spot.
              <br />
              <span style={{ color: LASER_PURPLE }}>Be first to launch.</span>
            </h2>
            <p className="text-white/35 text-base max-w-lg mx-auto mb-10">
              NazAI is launching to select founders first. Join the waitlist and get early access,
              priority onboarding, and a founding member price lock.
            </p>

            <motion.button
              onClick={() => setModalOpen(true)}
              className="inline-flex items-center gap-3 text-lg font-black px-10 py-5 rounded-2xl cursor-pointer"
              style={{
                background: `linear-gradient(135deg, ${LASER_PURPLE}, ${LASER_PURPLE_DIM})`,
                color: "#fff",
                boxShadow: `0 0 60px ${LASER_PURPLE}50, 0 0 120px ${LASER_PURPLE}25`,
              }}
              whileHover={{ scale: 1.05, boxShadow: `0 0 80px ${LASER_PURPLE}70, 0 0 150px ${LASER_PURPLE}35` }}
              whileTap={{ scale: 0.97 }}
            >
              Join Waitlist
              <ArrowRight className="w-5 h-5" />
            </motion.button>

            {totalCount > 0 && (
              <p className="text-xs text-white/25 mt-5">
                {totalCount.toLocaleString()} founders already waiting
              </p>
            )}
          </div>
        </Reveal>
      </section>

      {/* ── Testimonials ── */}
      <section className="mb-28 overflow-hidden">
        <Reveal className="text-center mb-12 px-6">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-white/10 bg-white/3 text-white/35 text-xs font-semibold tracking-[0.2em] uppercase mb-5">
            <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
            Neural Feedback
          </div>
          <h2 className="text-3xl md:text-5xl font-black tracking-tight text-white mb-4">
            Verified missions,{" "}
            <span style={{ color: LASER_PURPLE }}>calibrated by operators.</span>
          </h2>
          <p className="text-white/30 text-sm">Hover to pause. Every card is a real mission logged in the Vault.</p>
        </Reveal>
        <TestimonialsMarquee />
      </section>

      <Footer />
      <ManusDialog 
        open={showManusDialog} 
        onOpenChange={setShowManusDialog}
        onLogin={() => setShowManusDialog(false)}
        title="Welcome to NazAI"
      />

      {/* ── Modals ── */}
      <AnimatePresence>
        {modalOpen && (
          <WaitlistModal
            onClose={() => setModalOpen(false)}
            onSuccess={handleSuccess}
          />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {confirmation && (
          <ConfirmationView
            position={confirmation.position}
            name={confirmation.name}
            onClose={() => setConfirmation(null)}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
